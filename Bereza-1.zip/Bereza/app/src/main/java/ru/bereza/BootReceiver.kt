package ru.bereza

import android.content.*

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        try { c.startForegroundService(Intent(c, BerezaService::class.java)) } catch (_: Exception) {}
    }
}
