package ru.bereza

/** Сюда подключается официальный API/SDK автомобиля (если производитель его даёт). */
interface CarController {
    /** Вернуть текст ответа или null, если команда не про машину. */
    fun handle(command: String): String?
}

class NullCarController : CarController {
    private val words = listOf("климат", "кондиционер", "печк", "окно", "окна", "багажник",
        "замок", "двери", "обогрев", "подогрев", "зарядк")
    override fun handle(command: String): String? =
        if (words.any { command.lowercase().contains(it) })
            "Управление функциями машины пока не подключено. Нужен официальный доступ к API автомобиля."
        else null
}

class CompositeCar(private vararg val parts: CarController) : CarController {
    override fun handle(command: String): String? = parts.firstNotNullOfOrNull { it.handle(command) }
}
