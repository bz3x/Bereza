package ru.bereza

import android.content.*
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.view.KeyEvent
import java.text.SimpleDateFormat
import java.util.*

class CommandRouter(private val ctx: Context, private val car: CarController) {
    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val prefs = ctx.getSharedPreferences("bereza", Context.MODE_PRIVATE)

    private fun launch(i: Intent) = ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    private fun media(code: Int) {
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun openApp(name: String): Boolean {
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name) } ?: return false
        launch(pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return false)
        return true
    }

    private fun after(c: String, vararg keys: String): String {
        for (k in keys) if (c.contains(k)) return c.substringAfter(k).trim()
        return ""
    }

    fun handle(raw: String): String {
        val c = raw.lowercase().trim()
        car.handle(c)?.let { return it }
        return try {
            when {
                c.contains("что ты умеешь") || c.contains("помощь") ->
                    "Я умею: вести диалог, шутить, рассказывать сказки и факты, говорить погоду и время, " +
                    "строить маршруты, включать музыку и радио, звонить, ставить таймеры и будильники, " +
                    "искать в интернете, открывать приложения, писать сообщения и управлять климатом, если прошивка позволяет."
                c.contains("как дела") || c == "привет" || c.contains("привет") && c.length < 12 ->
                    AiClient(ctx).ask(raw, 120)
                c.contains("мой город") -> {
                    val city = after(c, "мой город").trim()
                    prefs.edit().putString("city", city).apply(); "Запомнила: ваш город $city"
                }
                c.contains("погод") -> {
                    val city = after(c, " в ").ifBlank { prefs.getString("city", "Москва")!! }
                    WeatherClient.forCity(city)
                }
                c.contains("анекдот") || c.contains("шутк") || c.contains("пошути") ->
                    AiClient(ctx).ask("Расскажи короткую добрую шутку", 200)
                c.contains("сказк") || c.contains("историю") || c.contains("расскажи рассказ") ->
                    AiClient(ctx).ask(raw, 700, "Расскажи короткую добрую историю на 1 минуту.")
                c.contains("загадк") -> AiClient(ctx).ask("Загадай мне загадку и скажи отгадку после паузы", 200)
                c.startsWith("навигация") || c.startsWith("поехали") || c.contains("построй маршрут") || c.startsWith("едем") -> {
                    val dest = after(c, " до ", " в ", " к ", " на ")
                    if (dest.isBlank()) "Куда поедем?" else {
                        launch(Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(dest))))
                        "Строю маршрут: $dest"
                    }
                }
                c.contains("найди на карте") || c.contains("где находится") || c.contains("ближайш") -> {
                    val q = after(c, "найди на карте", "где находится", "ближайш").ifBlank { c }
                    launch(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(q)))); "Ищу на карте: $q"
                }
                c.contains("следующ") -> { media(KeyEvent.KEYCODE_MEDIA_NEXT); "Следующий трек" }
                c.contains("предыдущ") -> { media(KeyEvent.KEYCODE_MEDIA_PREVIOUS); "Предыдущий трек" }
                c.contains("пауза") || c.contains("останови музыку") || c.contains("выключи музыку") -> { media(KeyEvent.KEYCODE_MEDIA_PAUSE); "Пауза" }
                c.contains("радио") -> {
                    val q = after(c, "радио").ifBlank { "" }
                    launch(Intent(android.provider.MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                        .putExtra(android.app.SearchManager.QUERY, "радио $q")); "Включаю радио $q"
                }
                c.contains("включи музыку") || c.contains("играй") || c.startsWith("включи песню") || c.contains("включи трек") -> {
                    val q = after(c, "играй", "песню", "трек")
                    if (q.isBlank()) { media(KeyEvent.KEYCODE_MEDIA_PLAY); "Включаю" } else {
                        launch(Intent(android.provider.MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                            .putExtra(android.app.SearchManager.QUERY, q)); "Ищу: $q" }
                }
                c.contains("громче") -> { audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); "Громче" }
                c.contains("тише") -> { audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); "Тише" }
                c.contains("без звука") -> { audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0); "Звук выключен" }
                c.startsWith("позвони") -> {
                    val num = c.filter { it.isDigit() || it == '+' }
                    launch(Intent(Intent.ACTION_DIAL, Uri.parse(if (num.length > 2) "tel:$num" else "tel:")))
                    "Открываю набор номера"
                }
                c.contains("сообщени") || c.startsWith("напиши") -> {
                    launch(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")).putExtra("sms_body", after(c, "текст", "напиши")))
                    "Открываю сообщения"
                }
                c.contains("будильник") -> {
                    val m = Regex("(\\d{1,2})[: ]?(\\d{2})?").find(c)
                    var h = m?.groupValues?.get(1)?.toIntOrNull() ?: return "На какое время?"
                    val min = m.groupValues[2].toIntOrNull() ?: 0
                    if ((c.contains("вечера") || c.contains("дня")) && h < 12) h += 12
                    launch(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h)
                        .putExtra(AlarmClock.EXTRA_MINUTES, min).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                    "Будильник на %d:%02d".format(h, min)
                }
                c.contains("таймер") -> {
                    val n = Regex("\\d+").find(c)?.value?.toIntOrNull() ?: 1
                    val sec = if (c.contains("секунд")) n else n * 60
                    launch(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, sec)
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                    "Таймер на $n ${if (c.contains("секунд")) "сек." else "мин."}"
                }
                c.contains("напомни") -> {
                    launch(Intent(Intent.ACTION_INSERT).setData(android.provider.CalendarContract.Events.CONTENT_URI)
                        .putExtra(android.provider.CalendarContract.Events.TITLE, after(c, "напомни")))
                    "Создаю напоминание"
                }
                c.contains("который час") || c.contains("сколько времени") ->
                    "Сейчас " + SimpleDateFormat("HH:mm", Locale("ru")).format(Date())
                c.contains("какое число") || c.contains("какой сегодня день") || c.contains("какая дата") ->
                    "Сегодня " + SimpleDateFormat("d MMMM, EEEE", Locale("ru")).format(Date())
                c.startsWith("открой") || c.startsWith("запусти") -> {
                    val n = after(c, "открой", "запусти")
                    if (openApp(n)) "Открываю $n" else "Не нашла приложение $n"
                }
                c.startsWith("найди") || c.startsWith("загугли") || c.contains("поиск в интернете") -> {
                    val q = after(c, "найди", "загугли", "поиск в интернете")
                    launch(Intent(Intent.ACTION_WEB_SEARCH).putExtra(android.app.SearchManager.QUERY, q)); "Ищу: $q"
                }
                c.contains("переведи") -> AiClient(ctx).ask(raw, 200)
                c.contains("посчитай") || c.contains("сколько будет") -> AiClient(ctx).ask(raw, 150, "Ответь только результатом.")
                else -> AiClient(ctx).ask(raw)
            }
        } catch (e: Exception) { "Не получилось выполнить команду" }
    }
}
