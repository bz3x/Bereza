package ru.bereza

import android.content.Context

/**
 * Климат через штатный Android Automotive Car API (CarPropertyManager), вызывается через reflection,
 * поэтому приложение собирается и запускается на любом Android. Работает только там, где ГУ
 * предоставляет этот API и система выдала приложению разрешение CONTROL_CAR_CLIMATE.
 * Движение, тормоза, рулевое и прочие системы безопасности намеренно не затрагиваются.
 */
class AaosCarController(private val ctx: Context) : CarController {
    private companion object {
        const val HVAC_POWER_ON = 0x15200510
        const val HVAC_AC_ON = 0x15200505
        const val HVAC_TEMP_SET = 0x15600503
        const val HVAC_FAN_SPEED = 0x15400500
        const val HVAC_DEFROSTER = 0x13200504
        const val GLOBAL = 0
        const val SEATS = 1 or 4 // передние левое и правое
        const val FRONT_WINDOW = 1
    }

    private val triggers = listOf("климат", "кондиционер", "печк", "обдув", "обогрев стекл", "температур", "вентилятор")
    private var mgr: Any? = null

    private fun manager(): Any? {
        mgr?.let { return it }
        return try {
            val carCls = Class.forName("android.car.Car")
            val car = carCls.getMethod("createCar", Context::class.java).invoke(null, ctx)
            try { carCls.getMethod("connect").invoke(car) } catch (_: Exception) {}
            mgr = carCls.getMethod("getCarManager", String::class.java).invoke(car, "property")
            mgr
        } catch (_: Throwable) { null }
    }

    private fun setBool(p: Int, area: Int, v: Boolean) =
        mgr!!.javaClass.getMethod("setBooleanProperty", Int::class.java, Int::class.java, Boolean::class.java)
            .invoke(mgr, p, area, v)

    private fun setFloat(p: Int, area: Int, v: Float) =
        mgr!!.javaClass.getMethod("setFloatProperty", Int::class.java, Int::class.java, Float::class.java)
            .invoke(mgr, p, area, v)

    private fun setInt(p: Int, area: Int, v: Int) =
        mgr!!.javaClass.getMethod("setIntProperty", Int::class.java, Int::class.java, Int::class.java)
            .invoke(mgr, p, area, v)

    override fun handle(command: String): String? {
        val c = command.lowercase()
        if (triggers.none { c.contains(it) }) return null
        if (manager() == null)
            return "Эта прошивка не открывает приложениям доступ к управлению климатом"
        val off = c.contains("выключ") || c.contains("отключ")
        return try {
            when {
                c.contains("обдув") || c.contains("обогрев стекл") -> {
                    setBool(HVAC_DEFROSTER, FRONT_WINDOW, !off); if (off) "Обдув выключен" else "Обдув стекла включён"
                }
                c.contains("температур") -> {
                    val t = Regex("\\d+").find(c)?.value?.toFloatOrNull()
                    if (t == null || t < 16 || t > 30) "Назовите температуру от 16 до 30 градусов"
                    else { setFloat(HVAC_TEMP_SET, SEATS, t); "Температура ${t.toInt()} градусов" }
                }
                c.contains("вентилятор") -> {
                    val n = Regex("\\d").find(c)?.value?.toIntOrNull()
                    if (n == null) "Назовите скорость вентилятора от 1 до 7"
                    else { setInt(HVAC_FAN_SPEED, GLOBAL, n.coerceIn(1, 7)); "Вентилятор на $n" }
                }
                c.contains("кондиционер") -> { setBool(HVAC_AC_ON, GLOBAL, !off); if (off) "Кондиционер выключен" else "Кондиционер включён" }
                else -> { setBool(HVAC_POWER_ON, GLOBAL, !off); if (off) "Климат выключен" else "Климат включён" }
            }
        } catch (e: Throwable) {
            "Система не разрешила приложению управлять климатом"
        }
    }
}
