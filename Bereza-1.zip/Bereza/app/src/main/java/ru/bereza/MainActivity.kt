package ru.bereza

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("bereza", Context.MODE_PRIVATE)
        fun field(hint: String, key: String, def: String) = EditText(this).apply {
            this.hint = hint; setText(p.getString(key, def)); setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
        }
        val key = field("API-ключ ИИ", "api_key", "")
        val model = field("Модель", "model", "claude-sonnet-5-5")
        val title = TextView(this).apply {
            text = "🐻 Берёза"; textSize = 32f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "Скажите «Берёза» и команду: навигация, музыка, звонок, громкость, таймер или любой вопрос."
            setTextColor(Color.LTGRAY)
        }
        val start = Button(this).apply {
            text = "Запустить Берёзу"
            setOnClickListener {
                p.edit().putString("api_key", key.text.toString().trim())
                    .putString("model", model.text.toString().trim()).apply()
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.CALL_PHONE), 1)
            }
        }
        val stop = Button(this).apply {
            text = "Остановить"
            setOnClickListener { stopService(Intent(this@MainActivity, BerezaService::class.java)) }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(48, 48, 48, 48)
            setBackgroundColor(Color.parseColor("#1B2A1F"))
            listOf(title, info, key, model, start, stop).forEach { addView(it) }
        })
    }

    override fun onRequestPermissionsResult(rc: Int, perms: Array<out String>, res: IntArray) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == 0)
            startForegroundService(Intent(this, BerezaService::class.java))
        else Toast.makeText(this, "Нужен доступ к микрофону", Toast.LENGTH_LONG).show()
    }
}
